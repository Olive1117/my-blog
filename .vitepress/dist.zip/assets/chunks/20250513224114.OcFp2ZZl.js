const s="/images/20250513224114.jpg";export{s as _};
